﻿using System;

class Program  //.net
{
    static void Main()
    {
        Console.WriteLine("Cálculo del Área de un Triángulo");

        // Solicitar la base del triángulo al usuario
        Console.Write("Ingrese la longitud de la base: ");
        double baseTriangulo = Convert.ToDouble(Console.ReadLine());

        // Solicitar la altura del triángulo al usuario
        Console.Write("Ingrese la altura: ");
        double alturaTriangulo = Convert.ToDouble(Console.ReadLine());

        // Calcular el área del triángulo
        double areaTriangulo = (baseTriangulo * alturaTriangulo) / 2.0;

        // Mostrar el resultado
        Console.WriteLine($"El área del triángulo es: {areaTriangulo}");

        Console.ReadLine(); // Esperar a que el usuario presione Enter para salir
    }
}
