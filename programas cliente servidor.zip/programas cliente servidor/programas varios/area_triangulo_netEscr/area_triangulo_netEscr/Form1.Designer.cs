﻿namespace area_triangulo_netEscr
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelBase = new Label();
            labelAltura = new Label();
            labelResultado = new Label();
            buttonCalcular = new Button();
            textBoxBase = new TextBox();
            textBoxAltura = new TextBox();
            SuspendLayout();
            // 
            // labelBase
            // 
            labelBase.AutoSize = true;
            labelBase.Location = new Point(60, 57);
            labelBase.Name = "labelBase";
            labelBase.Size = new Size(31, 15);
            labelBase.TabIndex = 0;
            labelBase.Text = "Base";
            // 
            // labelAltura
            // 
            labelAltura.AutoSize = true;
            labelAltura.Location = new Point(60, 104);
            labelAltura.Name = "labelAltura";
            labelAltura.Size = new Size(39, 15);
            labelAltura.TabIndex = 1;
            labelAltura.Text = "Altura";
            // 
            // labelResultado
            // 
            labelResultado.AutoSize = true;
            labelResultado.Location = new Point(208, 161);
            labelResultado.Name = "labelResultado";
            labelResultado.Size = new Size(112, 15);
            labelResultado.TabIndex = 2;
            labelResultado.Text = "                                   ";
            labelResultado.Click += label3_Click;
            // 
            // buttonCalcular
            // 
            buttonCalcular.Location = new Point(60, 157);
            buttonCalcular.Name = "buttonCalcular";
            buttonCalcular.Size = new Size(75, 23);
            buttonCalcular.TabIndex = 3;
            buttonCalcular.Text = "Calcular";
            buttonCalcular.UseVisualStyleBackColor = true;
            buttonCalcular.Click += buttonCalcular_Click;
            // 
            // textBoxBase
            // 
            textBoxBase.Location = new Point(208, 49);
            textBoxBase.Name = "textBoxBase";
            textBoxBase.Size = new Size(112, 23);
            textBoxBase.TabIndex = 4;
            // 
            // textBoxAltura
            // 
            textBoxAltura.Location = new Point(208, 101);
            textBoxAltura.Name = "textBoxAltura";
            textBoxAltura.Size = new Size(112, 23);
            textBoxAltura.TabIndex = 5;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(437, 308);
            Controls.Add(textBoxAltura);
            Controls.Add(textBoxBase);
            Controls.Add(buttonCalcular);
            Controls.Add(labelResultado);
            Controls.Add(labelAltura);
            Controls.Add(labelBase);
            Name = "Form1";
            Text = "Calcula Area Triangulo";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelBase;
        private Label labelAltura;
        private Label labelResultado;
        private Button buttonCalcular;
        private TextBox textBoxBase;
        private TextBox textBoxAltura;
    }
}