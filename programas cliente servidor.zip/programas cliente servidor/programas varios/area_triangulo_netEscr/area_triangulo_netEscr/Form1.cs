using System;
using System.Windows.Forms;
namespace area_triangulo_netEscr
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void buttonCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener la base y la altura del tri�ngulo desde los cuadros de texto
                double baseTriangulo = Convert.ToDouble(textBoxBase.Text);
                double alturaTriangulo = Convert.ToDouble(textBoxAltura.Text);

                // Calcular el �rea del tri�ngulo
                double areaTriangulo = (baseTriangulo * alturaTriangulo) / 2.0;

                // Mostrar el resultado en el control de etiqueta de resultado
                labelResultado.Text = $"�rea del tri�ngulo: {areaTriangulo:F2} ";
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese valores num�ricos v�lidos en la base y la altura.", "Error de entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}