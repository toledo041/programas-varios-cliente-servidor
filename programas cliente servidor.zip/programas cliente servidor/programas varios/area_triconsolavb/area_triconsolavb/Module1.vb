﻿'en  .net framework'
Imports System
Module Module1

    Sub Main()
        Console.WriteLine("Cálculo del Área de un Triángulo")

        ' Solicitar la base del triángulo al usuario
        Console.Write("Ingrese la longitud de la base: ")
        Dim baseTriangulo As Double = Convert.ToDouble(Console.ReadLine())

        ' Solicitar la altura del triángulo al usuario
        Console.Write("Ingrese la altura: ")
        Dim alturaTriangulo As Double = Convert.ToDouble(Console.ReadLine())

        ' Calcular el área del triángulo
        Dim areaTriangulo As Double = (baseTriangulo * alturaTriangulo) / 2.0

        ' Mostrar el resultado
        Console.WriteLine($"El área del triángulo es: {areaTriangulo}")

        ' Esperar a que el usuario presione Enter para salir
        Console.ReadLine()

    End Sub

End Module
