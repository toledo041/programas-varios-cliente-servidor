﻿using System;
using System.Data.SqlClient;

class Program
{
    static void Main()
    {
        // Cadena de conexión a la base de datos Northwind en SQL Server
        string connectionString = "Server=LAPTOP-I0I1BV8J;Database=Northwind1;Integrated Security=True;";
        

        // Crear una conexión a SQL Server
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            // Abrir la conexión
            connection.Open();

            // Crear un comando SQL para la consulta
            string query = "SELECT * FROM Region order by RegionID";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                // Ejecutar la consulta y obtener un lector de datos
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    // Iterar a través de los resultados y mostrarlos
                    while (reader.Read())
                    {
                        string RegionID = reader["RegionID"].ToString();
                        string RegionDescription = reader["RegionDescription"].ToString();

                        Console.WriteLine($"RegionID: {RegionID}, RegionDescription: {RegionDescription}");
                    }
                }
            }
        }

    }
}
