using System;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace FormSqlNet
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Cadena de conexi�n a la base de datos SQL Server
            string connectionString = "Server=LAPTOP-I0I1BV8J;Database=Northwind1;Integrated Security=True;";

            // Consulta SQL
            string query = "SELECT * FROM Region order by RegionID";

            // Crear una conexi�n a SQL Server
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Crear un adaptador de datos para ejecutar la consulta y llenar un DataSet
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataSet dataSet = new DataSet();

                // Abrir la conexi�n y llenar el DataSet
                connection.Open();
                adapter.Fill(dataSet, "Region"); 

                // Asignar el DataSet como origen de datos del DataGridView
                dataGridView1.DataSource = dataSet.Tables["Region"]; 
            }
        }
    }
}