﻿Imports System
Imports System.Data
Imports System.Data.SqlClient
Public Class Form1

    Dim ds As New DataSet
    Dim da As New SqlDataAdapter
    Dim conexion As SqlConnection
    Dim consulta As String

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Crear un nuevo DataSet
        Dim dataSet As New DataSet("Regions")

        ' Crear una tabla en el DataSet
        Dim dataTable As New DataTable("Regions")

        ' Definir las columnas de la tabla
        dataTable.Columns.Add("ID", GetType(Integer))
        dataTable.Columns.Add("Nombre", GetType(String))


        Dim cadena As String = "Server=LAPTOP-I0I1BV8J;Database=Northwind1;Integrated Security=True;"
        conexion = New SqlConnection(cadena)
        conexion.Open()
        consulta = "SELECT * FROM Region order by RegionID"

        da = New SqlDataAdapter(consulta, conexion)
        ' Llenar el DataSet con los datos de la base de datos
        da.Fill(ds, "Regions")

        conexion.Close()

        ' Llenar el DataSet con los datos de la base de datos
        da.Fill(dataSet, "Regions") ' Reemplaza "MiTabla" con el nombre de tu tabla

        ' Asignar el DataSet al control DataGridView para mostrar los datos
        DataGridView1.DataSource = dataSet.Tables("Regions")
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class
