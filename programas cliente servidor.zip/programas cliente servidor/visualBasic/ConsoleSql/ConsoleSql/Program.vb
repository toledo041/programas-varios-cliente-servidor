Imports System
Imports System.Data
Imports System.Data.SqlClient

Module Program
    Dim ds As New DataSet
    Dim da As New SqlDataAdapter
    Dim conexion As SqlConnection
    Dim consulta As String
    Sub Main(args As String())

        Dim cadena As String = "Server=LAPTOP-I0I1BV8J;Database=Northwind1;Integrated Security=True;"
        conexion = New SqlConnection(cadena)
        conexion.Open()
        consulta = "SELECT * FROM Region order by RegionID"

        da = New SqlDataAdapter(consulta, conexion)
        da.Fill(ds, "Region")
        Console.WriteLine("hasta aqui ")
        For Each r As DataRow In ds.Tables("Region").Rows
            For c = 0 To ds.Tables("Region").Columns.Count - 1
                Console.WriteLine(r.ItemArray(c).ToString() & " ")

            Next
        Next

        conexion.Close()



    End Sub
End Module
